
import React, { useState } from 'react';
import { User } from '../types';

interface InventoryModalProps {
  user: User;
  onClose: () => void;
  onUpdateUser: (user: User) => void;
}

const COLOR_MAP: Record<string, string> = {
  '#1abc9c': 'Cyan',
  '#23a559': 'Green',
  '#00a8fc': 'Blue',
  '#eb459e': 'Pink',
  '#000000': 'Black',
  '#f1c40f': 'Gold',
  '#313338': 'Invis',
  'white': 'Default White'
};

const InventoryModal: React.FC<InventoryModalProps> = ({ user, onClose, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'colors' | 'roles'>('colors');

  const equipColor = (colorCode: string) => {
    onUpdateUser({ ...user, tagColor: colorCode });
  };

  const handleEquipRole = (role: string) => {
    // If the role is already equipped, toggle it off (unequip)
    const newEquippedRole = user.equippedRole === role ? undefined : role;
    onUpdateUser({ ...user, equippedRole: newEquippedRole });
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-[#2b2d31] w-full max-w-lg rounded-2xl border border-white/5 shadow-2xl flex flex-col overflow-hidden">
        <div className="p-6 bg-[#232428] border-b border-[#1e1f22] flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#f1c40f]/10 rounded-xl flex items-center justify-center text-[#f1c40f]">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <div>
              <h2 className="text-xl font-black text-white uppercase tracking-tighter">My Inventory</h2>
              <p className="text-[10px] text-[#949ba4] font-bold uppercase tracking-widest">Personal Collection</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#949ba4] hover:text-white transition-colors p-2">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="flex gap-2 p-4 bg-[#2b2d31]">
           <button onClick={() => setActiveTab('colors')} className={`flex-1 py-2 rounded-lg text-xs font-black uppercase transition-all ${activeTab === 'colors' ? 'bg-[#f1c40f] text-[#1e1f22]' : 'bg-[#1e1f22] text-[#949ba4]'}`}>Unlocked Colors</button>
           <button onClick={() => setActiveTab('roles')} className={`flex-1 py-2 rounded-lg text-xs font-black uppercase transition-all ${activeTab === 'roles' ? 'bg-[#f1c40f] text-[#1e1f22]' : 'bg-[#1e1f22] text-[#949ba4]'}`}>Owned Roles</button>
        </div>

        <div className="p-4 overflow-y-auto max-h-[60vh] space-y-2">
          {activeTab === 'colors' ? (
            <div className="grid grid-cols-1 gap-2">
              {(user.unlockedColors || ['white']).map(colorCode => (
                <button 
                  key={colorCode} 
                  onClick={() => equipColor(colorCode)}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${user.tagColor === colorCode ? 'bg-[#f1c40f]/10 border-[#f1c40f]' : 'bg-[#1e1f22] border-transparent hover:border-white/10'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full border border-white/10 shadow-sm" style={{ backgroundColor: colorCode }}></div>
                    <span className="font-bold text-sm" style={{ color: colorCode }}>{COLOR_MAP[colorCode] || 'Custom Color'}</span>
                  </div>
                  {user.tagColor === colorCode ? (
                    <span className="text-[10px] bg-[#f1c40f] text-[#1e1f22] px-2 py-0.5 rounded font-black uppercase">Equipped</span>
                  ) : (
                    <span className="text-[10px] text-[#949ba4] font-bold uppercase group-hover:text-white transition-colors">Click to Equip</span>
                  )}
                </button>
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {(!user.roles || user.roles.length === 0) ? (
                <div className="text-center py-10">
                  <p className="text-[#949ba4] text-xs italic">You don't own any roles yet.</p>
                  <p className="text-[#949ba4] text-[10px] mt-1">Visit the Market or ask Nexus Core nicely!</p>
                </div>
              ) : (
                user.roles.map(role => (
                  <button
                    key={role}
                    onClick={() => handleEquipRole(role)}
                    className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all ${user.equippedRole === role ? 'bg-[#5865f2]/10 border-[#5865f2]' : 'bg-[#1e1f22] border-transparent hover:border-white/10'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-8 rounded-full ${role === 'AI' ? 'bg-[#a855f7]' : 'bg-[#5865f2]'}`}></div>
                      <div className="text-left">
                        <span className="font-black text-sm text-white uppercase tracking-tight block">{role}</span>
                        {role === 'AI' && <span className="text-[7px] text-[#a855f7] font-black uppercase tracking-widest">Earned from Nexus Core</span>}
                      </div>
                    </div>
                    {user.equippedRole === role ? (
                      <span className="text-[10px] bg-[#5865f2] text-white px-2 py-0.5 rounded font-black uppercase">Equipped</span>
                    ) : (
                      <span className="text-[10px] text-[#949ba4] font-bold uppercase">Equip</span>
                    )}
                  </button>
                ))
              )}
            </div>
          )}
        </div>
        
        <div className="p-4 flex justify-center border-t border-white/5 bg-[#232428]">
          <button onClick={onClose} className="text-[#b5bac1] hover:text-white text-[11px] font-black uppercase tracking-widest transition-colors">
            Close Inventory
          </button>
        </div>
      </div>
    </div>
  );
};

export default InventoryModal;
