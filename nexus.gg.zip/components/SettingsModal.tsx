
import React, { useState } from 'react';
import { User } from '../types';
import { isInappropriate, isPolitical } from '../utils/filter';

interface SettingsModalProps {
  user: User;
  onClose: () => void;
  onUpdateInfo: (updates: { email?: string; password?: string; newUsername?: string; cost?: number }) => Promise<string | null>;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ user, onClose, onUpdateInfo }) => {
  const [email, setEmail] = useState(user.email || '');
  const [newPassword, setNewPassword] = useState('');
  const [newUsername, setNewUsername] = useState(user.username);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const nameChangeCost = 1000 * Math.pow(2, user.nameChangeCount || 0);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setIsSubmitting(true);

    const updates: any = {};
    if (email !== user.email) updates.email = email;
    if (newPassword) updates.password = newPassword;
    
    if (newUsername !== user.username) {
      if (user.coins < nameChangeCost) {
        setError("Insufficient coins for name change!");
        setIsSubmitting(false);
        return;
      }
      if (isInappropriate(newUsername)) {
        setError("Username contains prohibited language.");
        setIsSubmitting(false);
        return;
      }
      if (isPolitical(newUsername)) {
        setError("Political usernames are not allowed.");
        setIsSubmitting(false);
        return;
      }
      updates.newUsername = newUsername;
      updates.cost = nameChangeCost;
    }

    if (Object.keys(updates).length === 0) {
      setError("No changes detected.");
      setIsSubmitting(false);
      return;
    }

    const errorMsg = await onUpdateInfo(updates);
    if (errorMsg) {
      setError(errorMsg);
    } else {
      setSuccess("Settings updated successfully!");
      setNewPassword('');
    }
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-[#2b2d31] w-full max-w-md rounded-2xl border border-white/5 shadow-2xl flex flex-col overflow-hidden">
        <div className="p-6 bg-[#232428] border-b border-[#1e1f22] flex justify-between items-center">
          <h2 className="text-xl font-bold text-white tracking-tight">User Settings</h2>
          <button onClick={onClose} className="text-[#949ba4] hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <form onSubmit={handleUpdate} className="p-6 space-y-4">
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-[#b5bac1] uppercase">Email Address</label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#1e1f22] rounded px-4 py-2 text-white outline-none focus:ring-1 focus:ring-[#5865f2]" 
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-[#b5bac1] uppercase">Change Password</label>
            <input 
              type="password" 
              placeholder="Leave blank to keep current"
              value={newPassword} 
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full bg-[#1e1f22] rounded px-4 py-2 text-white outline-none focus:ring-1 focus:ring-[#5865f2]" 
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-[#b5bac1] uppercase flex justify-between">
              Username
              <span className="text-yellow-500 lowercase">cost: {nameChangeCost.toLocaleString()} coins</span>
            </label>
            <input 
              type="text" 
              value={newUsername} 
              onChange={(e) => setNewUsername(e.target.value)}
              className="w-full bg-[#1e1f22] rounded px-4 py-2 text-white outline-none focus:ring-1 focus:ring-[#5865f2]" 
              maxLength={15}
            />
          </div>

          {error && <p className="text-[#f23f42] text-xs font-bold text-center">{error}</p>}
          {success && <p className="text-[#23a559] text-xs font-bold text-center">{success}</p>}

          <div className="flex flex-col gap-2 pt-2">
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white font-bold py-2.5 rounded transition-all disabled:opacity-50"
            >
              {isSubmitting ? 'Updating...' : 'Save Changes'}
            </button>
            <button 
              type="button" 
              onClick={onClose}
              className="w-full bg-transparent text-[#b5bac1] hover:underline text-xs py-2"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SettingsModal;
