
import React, { useState } from 'react';
import { NEXUS_LOGO_SVG, SOUNDS } from '../constants';
import confetti from 'canvas-confetti';

interface AdminPanelProps {
  isDiscoMode: boolean;
  onToggleDisco: () => void;
  onAction: (action: string, target: string, value?: any, reason?: string) => void;
  onBroadcast: (text: string) => void;
  onSoundBroadcast: (soundKey: string, global: boolean) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ isDiscoMode, onToggleDisco, onAction, onBroadcast, onSoundBroadcast }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [targetUser, setTargetUser] = useState('');
  const [amount, setAmount] = useState('100');
  const [badgeTarget, setBadgeTarget] = useState('');
  const [badgeName, setBadgeName] = useState('');
  const [reason, setReason] = useState('');
  const [broadcastText, setBroadcastText] = useState('');
  const [isGlobalSound, setIsGlobalSound] = useState(true);
  const [confettiOnCooldown, setConfettiOnCooldown] = useState(false);

  const handleAction = (action: string) => {
    if (action === 'givebadge') {
      onAction('givebadge', badgeTarget, badgeName, "Badge assigned by Admin");
      setBadgeTarget('');
      setBadgeName('');
    } else {
      onAction(action, targetUser, amount, reason || "Admin request");
      setTargetUser('');
    }
  };

  const handleSendBroadcast = () => {
    if (!broadcastText.trim()) return;
    onBroadcast(broadcastText);
    setBroadcastText('');
  };

  const handleConfetti = () => {
    if (confettiOnCooldown) return;
    
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#5865f2', '#ffffff', '#23a559', '#f1c40f']
    });

    setConfettiOnCooldown(true);
    setTimeout(() => setConfettiOnCooldown(false), 500);
  };

  const soundOptions = [
    { key: 'duck', label: '🦆 Duck', color: 'bg-yellow-600' },
    { key: 'honk', label: '📯 Honk', color: 'bg-orange-600' },
    { key: 'win', label: '🏆 Win', color: 'bg-green-600' },
    { key: 'clap', label: '👏 Clap', color: 'bg-blue-600' },
    { key: 'cash', label: '💰 Cash', color: 'bg-emerald-600' },
  ];

  return (
    <div className="fixed bottom-6 right-6 flex flex-col items-end z-[400]">
      {isOpen && (
        <div className="bg-[#1e1f22] border border-white/10 rounded-2xl shadow-2xl p-4 mb-4 w-[320px] animate-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/5">
            <h3 className="text-white font-bold text-xs tracking-tight uppercase opacity-50">Command Center</h3>
            <button onClick={() => setIsOpen(false)} className="text-[#949ba4] hover:text-white transition-colors">✕</button>
          </div>

          <div className="space-y-4 max-h-[500px] overflow-y-auto custom-scrollbar pr-1">
            
            {/* Sound Board Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-[#5865f2] uppercase tracking-widest">Sound Board</label>
                <button 
                  onClick={() => setIsGlobalSound(!isGlobalSound)}
                  className={`text-[9px] px-2 py-0.5 rounded font-black uppercase transition-all ${isGlobalSound ? 'bg-[#5865f2] text-white' : 'bg-[#313338] text-[#949ba4]'}`}
                >
                  {isGlobalSound ? 'Global' : 'Local Channel'}
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {soundOptions.map((s) => (
                  <button
                    key={s.key}
                    onClick={() => onSoundBroadcast(s.key, isGlobalSound)}
                    className={`${s.color} hover:brightness-125 text-white text-[10px] font-black py-2 rounded shadow-lg transition-all active:scale-95 uppercase tracking-tight`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* General Target & Coins */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <label className="text-[10px] font-bold text-[#949ba4] uppercase">General Commands</label>
              <input 
                type="text" 
                placeholder="Target username or 'all'..." 
                value={targetUser} 
                onChange={(e) => setTargetUser(e.target.value)} 
                className="w-full bg-[#2b2d31] text-white text-xs px-3 py-2 rounded outline-none border border-transparent focus:border-[#5865f2]" 
              />
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Coin amount..." 
                  value={amount} 
                  onChange={(e) => setAmount(e.target.value)} 
                  className="flex-1 bg-[#2b2d31] text-white text-xs px-3 py-2 rounded outline-none" 
                />
                <button 
                  onClick={() => handleAction('givecoins')} 
                  className="bg-[#23a559] text-white text-[10px] font-bold px-3 rounded hover:brightness-110 active:scale-95 transition-all"
                >
                  Give Coins
                </button>
              </div>
            </div>

            {/* Global Broadcast */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <label className="text-[10px] font-bold text-[#949ba4] uppercase">Global Messaging (SYSTEM)</label>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Message to all channels..." 
                  value={broadcastText} 
                  onChange={(e) => setBroadcastText(e.target.value)} 
                  className="flex-1 bg-[#2b2d31] text-white text-xs px-3 py-2 rounded outline-none border border-transparent focus:border-[#5865f2]" 
                />
                <button 
                  onClick={handleSendBroadcast} 
                  className="bg-[#5865f2] text-white text-[10px] font-bold px-3 rounded hover:brightness-110 active:scale-95 transition-all"
                >
                  Broadcast
                </button>
              </div>
            </div>

            {/* Specific Badge Giver */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <label className="text-[10px] font-bold text-[#949ba4] uppercase">Give Badge/Rank</label>
              <div className="flex flex-col gap-2">
                <div className="space-y-1">
                  <p className="text-[9px] text-[#b5bac1] ml-1">To Who:</p>
                  <input 
                    type="text" 
                    placeholder="Username or 'all'..." 
                    value={badgeTarget} 
                    onChange={(e) => setBadgeTarget(e.target.value)} 
                    className="w-full bg-[#2b2d31] text-white text-xs px-3 py-2 rounded outline-none border border-transparent focus:border-[#5865f2]" 
                  />
                </div>
                <div className="space-y-1">
                  <p className="text-[9px] text-[#b5bac1] ml-1">What Badge:</p>
                  <input 
                    type="text" 
                    placeholder="Badge Name (e.g. OG, MOD)..." 
                    value={badgeName} 
                    onChange={(e) => setBadgeName(e.target.value)} 
                    className="w-full bg-[#2b2d31] text-white text-xs px-3 py-2 rounded outline-none border border-transparent focus:border-[#5865f2]" 
                  />
                </div>
                <button 
                  onClick={() => handleAction('givebadge')} 
                  className="w-full bg-[#5865f2] text-white text-[10px] font-bold py-2 rounded hover:brightness-110 active:scale-95 transition-all"
                >
                  Confirm Badge Giver
                </button>
              </div>
            </div>

            {/* Punishments & Fun */}
            <div className="pt-2 border-t border-white/5 flex flex-col gap-2">
              <button 
                onClick={() => handleAction('ban')} 
                className="w-full bg-[#ed4245] text-white text-[10px] font-bold py-2 rounded hover:brightness-110 active:scale-95 transition-all"
              >
                Ban Targeted User
              </button>

              <button 
                onClick={onToggleDisco} 
                className="w-full bg-[#4e5058] text-white text-[10px] font-bold py-2 rounded hover:bg-[#676a72] transition-colors"
              >
                {isDiscoMode ? 'Deactivate Disco' : 'Activate Disco'}
              </button>

              <button 
                onClick={handleConfetti} 
                disabled={confettiOnCooldown}
                className={`w-full text-white text-[10px] font-bold py-2 rounded transition-all active:scale-95 ${confettiOnCooldown ? 'bg-[#35373c] text-[#72767d] cursor-not-allowed' : 'bg-[#f1c40f] hover:bg-[#d4ac0d]'}`}
              >
                🎊 Confetti 🎊
              </button>
            </div>
          </div>
        </div>
      )}

      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 bg-[#1e1f22] border-2 border-[#5865f2] hover:scale-110 active:scale-95 group relative"
      >
        <img src={NEXUS_LOGO_SVG} alt="N" className="w-8 h-8 object-contain" />
        <div className="absolute right-16 px-3 py-1 bg-black text-white text-[10px] font-bold rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
          Nexus Control
        </div>
      </button>
    </div>
  );
};

export default AdminPanel;
