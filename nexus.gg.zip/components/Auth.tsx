
import React, { useState, useRef } from 'react';
import { User } from '../types';
import { STORAGE_KEYS, NEXUS_LOGO_SVG } from '../constants';
import { isInappropriate, isPolitical } from '../utils/filter';

interface AuthProps {
  onLogin: (user: User, isNewUser?: boolean) => void;
}

interface UserRecord {
  password: string;
  email: string;
  isBanned?: boolean;
  banReason?: string;
  timeoutUntil?: number;
  timeoutReason?: string;
  isVerified?: boolean;
  warnings?: number;
  banUntil?: number;
}

type AuthView = 'login' | 'register' | 'forgot' | 'reset';

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [view, setView] = useState<AuthView>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [avatar, setAvatar] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [restrictionDetail, setRestrictionDetail] = useState<{ reason: string; timeLeft?: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getStoredUsers = (): Record<string, UserRecord> => {
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    return data ? JSON.parse(data) : {};
  };

  const saveUser = (user: string, pass: string, mail: string) => {
    const users = getStoredUsers();
    users[user.toLowerCase()] = { 
      password: pass, 
      email: mail,
      isVerified: false, 
      warnings: 0 
    };
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setAvatar(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setRestrictionDetail(null);
    
    if (view === 'forgot') {
      const users = getStoredUsers();
      const userFound = Object.entries(users).find(([_, r]) => r.email === email);
      if (userFound) {
        setIsLoading(true);
        setTimeout(() => {
          setSuccess(`A reset link has been sent to ${email}`);
          setIsLoading(false);
          setTimeout(() => {
            setUsername(userFound[0]);
            setView('reset');
            setSuccess('');
          }, 2000);
        }, 1000);
      } else {
        setError('No account found with that email.');
      }
      return;
    }

    if (view === 'reset') {
      if (newPassword.length < 2) return setError('Password too short.');
      const users = getStoredUsers();
      if (users[username]) {
        users[username].password = newPassword;
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
        setSuccess('Password updated successfully! Redirecting...');
        setTimeout(() => setView('login'), 1500);
      }
      return;
    }

    if (!username || !password || (view === 'register' && !email)) {
      setError('Please fill in all fields.');
      return;
    }

    // Username Moderation
    if (view === 'register') {
      if (isInappropriate(username)) {
        setError('That username is not allowed (Nexus Policy).');
        return;
      }
      if (isPolitical(username)) {
        setError('Political usernames are prohibited.');
        return;
      }
    }

    setIsLoading(true);
    
    setTimeout(() => {
      const users = getStoredUsers();
      const normalizedUser = username.toLowerCase();

      if (view === 'login') {
        const record = users[normalizedUser];
        if (record && record.password === password) {
          if (record.isBanned) {
            setError('Account Permanently Banned');
            setRestrictionDetail({ reason: record.banReason || 'Administrative decision.' });
          } else if (record.banUntil && record.banUntil > Date.now()) {
            setError(`Suspension Active`);
            setRestrictionDetail({ reason: `Try again later.` });
          } else {
            onLogin({
              username: username,
              email: record.email,
              avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${normalizedUser}&backgroundColor=5865f2`,
              joinedAt: Date.now(),
              isVerified: record.isVerified,
              coins: 0,
              warnings: record.warnings || 0
            }, false);
          }
        } else {
          setError('Invalid username or password.');
        }
      } else if (view === 'register') {
        if (users[normalizedUser]) {
          setError('Someone already has that name.');
        } else {
          saveUser(username, password, email);
          onLogin({
            username: username,
            email: email,
            avatar: avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${normalizedUser}&backgroundColor=5865f2`,
            joinedAt: Date.now(),
            isVerified: false,
            coins: 0,
            warnings: 0
          }, true);
        }
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="h-screen w-screen flex items-center justify-center bg-[#313338] bg-[url('https://discord.com/assets/f4a019488e00192e2729.png')] bg-cover">
      <div className="w-full max-w-[480px] bg-[#313338] shadow-2xl p-8 rounded-lg flex flex-col items-center">
        <div className="flex flex-col items-center mb-6 text-center">
          <img src={NEXUS_LOGO_SVG} alt="Nexus N" className="w-12 h-12 mb-4 drop-shadow-xl object-contain" />
          <h1 className="text-5xl font-black text-white tracking-tighter uppercase mb-1">NEXUS</h1>
          <p className="text-[#5865f2] font-bold text-xs">Chatting Safely</p>
        </div>

        <form onSubmit={handleSubmit} className="w-full space-y-5">
          {view === 'forgot' ? (
            <div className="space-y-4">
              <p className="text-[#b5bac1] text-sm text-center">Enter your email to receive a password reset link.</p>
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-[#b5bac1] uppercase">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#1e1f22] rounded px-4 py-2.5 text-white outline-none focus:ring-1 focus:ring-[#5865f2]"
                  required
                />
              </div>
            </div>
          ) : view === 'reset' ? (
            <div className="space-y-4">
              <p className="text-[#b5bac1] text-sm text-center">Resetting password for <strong>{username}</strong></p>
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-[#b5bac1] uppercase">New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-[#1e1f22] rounded px-4 py-2.5 text-white outline-none focus:ring-1 focus:ring-[#5865f2]"
                  required
                />
              </div>
            </div>
          ) : (
            <>
              {view === 'register' && (
                <div className="flex flex-col items-center gap-2 mb-2">
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="w-20 h-20 rounded-full bg-[#1e1f22] border-2 border-dashed border-[#4e5058] flex items-center justify-center cursor-pointer hover:border-[#5865f2] overflow-hidden"
                  >
                    {avatar ? <img src={avatar} alt="Avatar" className="w-full h-full object-cover" /> : <span className="text-[#b5bac1] text-xs">Avatar</span>}
                  </div>
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                </div>
              )}

              <div className="space-y-2">
                <label className="text-[11px] font-bold text-[#b5bac1] uppercase">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-[#1e1f22] rounded px-4 py-2.5 text-white outline-none focus:ring-1 focus:ring-[#5865f2]"
                  maxLength={15}
                />
              </div>

              {view === 'register' && (
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-[#b5bac1] uppercase">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#1e1f22] rounded px-4 py-2.5 text-white outline-none focus:ring-1 focus:ring-[#5865f2]"
                  />
                </div>
              )}

              <div className="space-y-2 relative">
                <label className="text-[11px] font-bold text-[#b5bac1] uppercase">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#1e1f22] rounded px-4 py-2.5 text-white outline-none focus:ring-1 focus:ring-[#5865f2]"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#949ba4] hover:text-white"
                  >
                    {showPassword ? (
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.068m5.841-3.333A9.959 9.959 0 0112 5c4.478 0 8.268 2.943 9.542 7a10.028 10.028 0 01-4.558 5.768M15 12a3 3 0 11-6 0 3 3 0 016 0zm6 6l-6-6m1.414-1.414L19 19"/></svg>
                    )}
                  </button>
                </div>
              </div>
            </>
          )}

          {error && (
            <div className="bg-[#f23f42]/10 p-2 rounded border border-[#f23f42]/20">
              <p className="text-[#f23f42] text-xs text-center font-bold">{error}</p>
              {restrictionDetail && <p className="text-[#dbdee1] text-[10px] text-center mt-1">{restrictionDetail.reason}</p>}
            </div>
          )}
          {success && <p className="text-[#23a559] text-xs text-center font-bold">{success}</p>}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white font-bold py-3 rounded transition-all uppercase text-xs"
          >
            {isLoading ? 'Wait...' : view === 'login' ? 'Log In' : view === 'forgot' ? 'Send Link' : view === 'reset' ? 'Save New Password' : 'Join Nexus'}
          </button>
        </form>

        <div className="mt-4 flex flex-col items-center gap-2 text-sm">
          {view === 'login' ? (
            <>
              <button onClick={() => setView('forgot')} className="text-[#00a8fc] hover:underline">Forgot password?</button>
              <p className="text-[#b5bac1]">Need an account? <button onClick={() => setView('register')} className="text-[#00a8fc] hover:underline">Register</button></p>
            </>
          ) : (
            <button onClick={() => setView('login')} className="text-[#00a8fc] hover:underline">Back to Login</button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auth;
