
import React, { useState } from 'react';
import { User } from '../types';

interface ShopModalProps {
  user: User;
  onClose: () => void;
  onUpdateUser: (user: User) => void;
}

const COLORS = [
  { name: 'Cyan', color: '#1abc9c', price: 800 },
  { name: 'Green', color: '#23a559', price: 500 },
  { name: 'Blue', color: '#00a8fc', price: 500 },
  { name: 'Pink', color: '#eb459e', price: 1000 },
  { name: 'Black', color: '#000000', price: 2000 },
  { name: 'Gold', color: '#f1c40f', price: 2500 },
  { name: 'Invis', color: '#313338', price: 100000 },
];

const ROLES = [
  { name: 'BRICKLING', price: 500, color: '#964B00', description: 'A small brick in the wall.' },
  { name: 'BANANA', price: 1000, color: '#FFE135', description: 'Potassium power!' },
  { name: 'GOOBER', price: 1000, color: '#A29BFE', description: 'Just a total goober.' },
  { name: 'VIP', price: 10000, color: '#5865F2', description: 'Very Important Person.' },
  { name: 'Nexus Queen', price: 50000, color: '#FF79C6', description: 'Royalty of the network.' },
  { name: 'Nexus King', price: 50000, color: '#50FA7B', description: 'High monarch of Nexus.' },
];

const ShopModal: React.FC<ShopModalProps> = ({ user, onClose, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'colors' | 'roles'>('colors');

  const handleBuy = (type: 'color' | 'role', val: string, price: number) => {
    if (user.coins < price) return alert("Insufficient funds!");
    
    if (type === 'color') {
      const alreadyOwned = user.unlockedColors?.includes(val);
      if (alreadyOwned) return alert("You already own this color!");
      
      onUpdateUser({ 
        ...user, 
        coins: user.coins - price, 
        tagColor: val,
        unlockedColors: Array.from(new Set([...(user.unlockedColors || []), val]))
      });
    } else {
      const alreadyOwned = user.roles?.includes(val);
      if (alreadyOwned) return alert("You already have this role!");

      onUpdateUser({ 
        ...user, 
        coins: user.coins - price, 
        roles: [...(user.roles || []), val] 
      });
    }
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-[#2b2d31] w-full max-w-lg rounded-2xl border border-white/5 shadow-2xl flex flex-col overflow-hidden">
        <div className="p-6 bg-[#232428] border-b border-[#1e1f22] flex justify-between items-center">
          <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Nexus Market</h2>
          <div className="bg-[#1e1f22] px-4 py-1.5 rounded-full border border-yellow-500/20 flex items-center gap-2">
            <span className="text-yellow-500">🪙</span>
            <span className="text-white font-bold text-sm">{user.coins.toLocaleString()}</span>
          </div>
        </div>
        <div className="flex gap-2 p-4 bg-[#2b2d31]">
           <button onClick={() => setActiveTab('colors')} className={`flex-1 py-2 rounded-lg text-xs font-black uppercase transition-all ${activeTab === 'colors' ? 'bg-[#5865f2] text-white' : 'bg-[#1e1f22] text-[#949ba4]'}`}>Colors</button>
           <button onClick={() => setActiveTab('roles')} className={`flex-1 py-2 rounded-lg text-xs font-black uppercase transition-all ${activeTab === 'roles' ? 'bg-[#5865f2] text-white' : 'bg-[#1e1f22] text-[#949ba4]'}`}>Roles</button>
        </div>
        <div className="p-4 overflow-y-auto max-h-[60vh] space-y-2">
          {activeTab === 'colors' ? COLORS.map(c => {
            const isOwned = user.unlockedColors?.includes(c.color);
            return (
              <button 
                key={c.name} 
                onClick={() => handleBuy('color', c.color, c.price)} 
                disabled={isOwned}
                className={`w-full flex items-center justify-between p-3 bg-[#1e1f22] rounded-xl border border-transparent transition-all ${isOwned ? 'opacity-50 cursor-default' : 'hover:border-white/10'}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full" style={{backgroundColor: c.color}}></div>
                  <span className="font-bold text-sm" style={{color: c.color}}>{c.name}</span>
                  {isOwned && <span className="text-[10px] text-[#949ba4] uppercase font-black ml-2">Owned</span>}
                </div>
                <span className="text-xs font-bold text-yellow-500">{c.price.toLocaleString()} 🪙</span>
              </button>
            );
          }) : ROLES.map(r => {
            const isOwned = user.roles?.includes(r.name);
            return (
              <button 
                key={r.name} 
                onClick={() => handleBuy('role', r.name, r.price)} 
                disabled={isOwned}
                className={`w-full flex items-center justify-between p-3 bg-[#1e1f22] rounded-xl border border-transparent transition-all text-left ${isOwned ? 'opacity-50 cursor-default' : 'hover:border-white/10'}`}
              >
                <div>
                  <p className="font-bold text-sm" style={{color: r.color}}>
                    {r.name}
                    {isOwned && <span className="text-[10px] text-[#949ba4] uppercase font-black ml-2">Owned</span>}
                  </p>
                  <p className="text-[10px] text-[#949ba4]">{r.description}</p>
                </div>
                <span className="text-xs font-bold text-yellow-500 shrink-0 ml-4">{r.price.toLocaleString()} 🪙</span>
              </button>
            );
          })}
        </div>
        <div className="p-4 flex justify-center"><button onClick={onClose} className="text-[#949ba4] text-xs font-bold uppercase hover:text-white underline">Back to Chat</button></div>
      </div>
    </div>
  );
};

export default ShopModal;
