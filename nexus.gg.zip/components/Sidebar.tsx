
import React, { useRef } from 'react';
import { CHANNELS, NEXUS_LOGO_SVG } from '../constants';
import { Channel, User } from '../types';

interface SidebarProps {
  activeChannelId: string;
  onChannelSelect: (id: string) => void;
  currentUser: User | null;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
  onOpenShop: () => void;
  onOpenSettings: () => void;
  onOpenInventory: () => void;
  dynamicTickets?: Channel[];
}

const Sidebar: React.FC<SidebarProps> = ({ 
  activeChannelId, 
  onChannelSelect, 
  currentUser, 
  onLogout, 
  onUpdateUser, 
  onOpenShop,
  onOpenSettings,
  onOpenInventory,
  dynamicTickets = []
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && currentUser) {
      const reader = new FileReader();
      reader.onloadend = () => onUpdateUser({ ...currentUser, avatar: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  const isAdmin = currentUser?.username === "Brick";

  // Filter channels based on access
  const visibleChannels = CHANNELS.filter(ch => {
    if (ch.id === 'mod-actions') return isAdmin;
    return true;
  });

  return (
    <div className="flex h-full">
      <div className="w-[72px] bg-[#1e1f22] flex flex-col items-center py-3 gap-2 shrink-0">
        <div className="w-12 h-12 bg-[#313338] rounded-2xl flex items-center justify-center shadow-lg border border-white/5 hover:border-[#5865f2]/50 transition-colors">
          <img src={NEXUS_LOGO_SVG} className="w-8 h-8 object-contain" alt="Nexus" />
        </div>
        <div className="w-8 h-[2px] bg-[#35363c] rounded-full mx-auto my-1"></div>
        
        {/* Shop Button */}
        <button 
          onClick={onOpenShop} 
          className="w-12 h-12 bg-[#313338] hover:bg-[#23a559] hover:rounded-2xl rounded-full flex items-center justify-center text-[#23a559] hover:text-white transition-all shadow-md group relative"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
          <div className="absolute left-16 px-3 py-1 bg-black text-white text-xs font-bold rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
            Nexus Market
          </div>
        </button>

        {/* Inventory Button */}
        <button 
          onClick={onOpenInventory} 
          className="w-12 h-12 bg-[#313338] hover:bg-[#f1c40f] hover:rounded-2xl rounded-full flex items-center justify-center text-[#f1c40f] hover:text-white transition-all shadow-md group relative"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
          <div className="absolute left-16 px-3 py-1 bg-black text-white text-xs font-bold rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
            My Inventory
          </div>
        </button>

        {/* Settings Button */}
        <button 
          onClick={onOpenSettings} 
          className="w-12 h-12 bg-[#313338] hover:bg-[#5865f2] hover:rounded-2xl rounded-full flex items-center justify-center text-[#b5bac1] hover:text-white transition-all shadow-md group relative"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <div className="absolute left-16 px-3 py-1 bg-black text-white text-xs font-bold rounded-md whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
            User Settings
          </div>
        </button>
      </div>

      <div className="w-60 bg-[#2b2d31] flex flex-col h-full border-r border-black/10">
        <div className="h-12 px-4 shadow-sm flex items-center border-b border-[#1f2124] bg-[#2b2d31] z-10">
          <h1 className="font-bold text-white text-base truncate flex items-center gap-2">Nexus Chat</h1>
        </div>

        <div className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5 custom-scrollbar">
          <span className="px-2 text-[11px] font-bold text-[#949ba4] block mb-1">Channels</span>
          {visibleChannels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => onChannelSelect(channel.id)}
              className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded group transition-colors ${
                activeChannelId === channel.id ? 'bg-[#3f4147] text-white' : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
              }`}
            >
              <span className="text-xl text-[#80848e]">#</span>
              <span className="font-medium text-sm truncate capitalize">{channel.name}</span>
            </button>
          ))}

          {dynamicTickets.length > 0 && (
            <>
              <div className="mt-4 px-2 text-[11px] font-bold text-[#949ba4] block mb-1 uppercase tracking-wider">Active Support</div>
              {dynamicTickets.map((ticket) => (
                <button
                  key={ticket.id}
                  onClick={() => onChannelSelect(ticket.id)}
                  className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded group transition-colors ${
                    activeChannelId === ticket.id ? 'bg-[#3f4147] text-white' : 'text-[#949ba4] hover:bg-[#35373c] hover:text-[#dbdee1]'
                  }`}
                >
                  <span className="text-xl text-[#80848e]">🔒</span>
                  <span className="font-medium text-xs truncate capitalize">{ticket.name}</span>
                </button>
              ))}
            </>
          )}
        </div>

        <div className="bg-[#232428] p-2 space-y-2">
          {currentUser && (
            <>
              <div className="px-2 py-1.5 bg-[#1e1f22] rounded flex flex-col gap-1 shadow-inner">
                <div className="flex justify-between items-center gap-2">
                  <span className="text-yellow-500 text-[10px] font-bold whitespace-nowrap">🪙 {currentUser.coins.toLocaleString()}</span>
                  <div className="flex flex-wrap gap-1 justify-end min-w-0 overflow-hidden">
                    {/* Roles Display */}
                    {currentUser.roles?.map(r => (
                      <span key={r} className={`text-[7px] px-1 rounded font-black uppercase whitespace-nowrap ${r === 'AI' ? 'bg-[#a855f7] text-white' : 'bg-[#4e5058] text-[#dbdee1]'}`}>
                        {r}
                      </span>
                    ))}
                    {/* Badges Display */}
                    {currentUser.badges?.map(b => (
                      <span key={b} className="text-[7px] bg-[#5865f2] text-white px-1 rounded font-bold uppercase whitespace-nowrap">{b}</span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 p-1.5 rounded hover:bg-[#35373c] transition-colors">
                <div onClick={() => fileInputRef.current?.click()} className="relative cursor-pointer shrink-0">
                  <img src={currentUser.avatar} alt={currentUser.username} className="w-8 h-8 rounded-full object-cover bg-[#313338]" />
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-bold text-white truncate" style={{ color: currentUser.tagColor }}>
                    {currentUser.equippedRole ? `(${currentUser.equippedRole}) ` : ''}{currentUser.username}
                  </p>
                  <p className="text-[11px] text-[#23a559] font-medium leading-tight">Online</p>
                </div>
                <button onClick={onLogout} className="p-1 text-[#b5bac1] hover:text-[#ed4245] transition-colors">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
