
import React, { useState, useEffect, useRef } from 'react';
import { Channel, Message, User, ChannelType, SupportSubmission, SuggestionSubmission } from '../types';
import { getAIChatResponse } from '../services/geminiService';
import { NEXUS_LOGO_SVG } from '../constants';

interface ChatAreaProps {
  activeChannel: Channel;
  messages: Message[];
  onSendMessage: (text: string, isAI?: boolean) => void;
  onImageUpload: (imageData: string) => Promise<void>;
  onGrantRole: (roleName: string) => void;
  onFormSubmit?: (data: any) => void;
  onOpenTicket?: (subId: string) => void;
  onCloseTicket?: (ticketId: string) => void;
  currentUser: User | null;
  timeoutUntil: number | null;
  timeoutReason?: string | null;
  onTimeoutEnd: () => void;
  submissions?: SupportSubmission[];
  suggestions?: SuggestionSubmission[];
}

const ChatArea: React.FC<ChatAreaProps> = ({ 
  activeChannel, 
  messages, 
  onSendMessage, 
  onImageUpload, 
  onGrantRole,
  onFormSubmit,
  onOpenTicket,
  onCloseTicket,
  currentUser,
  timeoutUntil,
  timeoutReason,
  onTimeoutEnd,
  submissions = [],
  suggestions = []
}) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  
  // Support Form states
  const [formNeed, setFormNeed] = useState('');
  const [formDetails, setFormDetails] = useState('');

  // Suggestion Form states
  const [suggestionWant, setSuggestionWant] = useState('');
  const [suggestionWhy, setSuggestionWhy] = useState('');

  const scrollRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const isAdmin = currentUser?.username === "Brick";
  const isAnnouncements = activeChannel.id === 'announcements';
  const isTimedOut = timeoutUntil !== null && Date.now() < timeoutUntil;
  const canChat = (activeChannel.type !== ChannelType.FORM) && (!isAnnouncements || isAdmin) && !isScanning && !isTimedOut;

  useEffect(() => {
    let interval: number | undefined;
    if (isTimedOut) {
      const update = () => {
        const remaining = Math.max(0, Math.ceil((timeoutUntil! - Date.now()) / 1000));
        setTimeLeft(remaining);
        if (remaining <= 0) {
          onTimeoutEnd();
          clearInterval(interval);
        }
      };
      update();
      interval = window.setInterval(update, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimedOut, timeoutUntil, onTimeoutEnd]);

  const visibleMessages = messages.filter(m => !m.recipient || m.recipient === currentUser?.username);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [visibleMessages, isTyping, isScanning, activeChannel.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !canChat) return;
    const userText = inputText.trim();
    setInputText('');
    onSendMessage(userText);
    
    if (activeChannel.type === ChannelType.AI) {
      setIsTyping(true);
      const history: { role: 'user' | 'model'; text: string }[] = messages
        .filter(m => m.channelId === activeChannel.id)
        .slice(-10)
        .map(m => ({ role: m.isAI ? 'model' : 'user', text: m.text }));
      
      const aiResult = await getAIChatResponse(userText, history);
      
      if (aiResult.functionCalls) {
        for (const fc of aiResult.functionCalls) {
          if (fc.name === 'grantAIRole') {
            const alreadyHasRole = currentUser?.roles?.includes('AI');
            if (!alreadyHasRole) {
              onGrantRole('AI');
              onSendMessage("✨ PROTOCOL UPDATE: Politeness detected. Granting 'AI' role to user profile.", true);
            }
          }
        }
      }

      onSendMessage(aiResult.text, true);
      setIsTyping(false);
    }
  };

  const handleGeneralFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeChannel.id === 'suggestions') {
      if (!suggestionWant.trim() || !suggestionWhy.trim()) return;
      onFormSubmit?.({ want: suggestionWant, why: suggestionWhy });
      setSuggestionWant('');
      setSuggestionWhy('');
    } else {
      if (!formNeed.trim() || !formDetails.trim()) return;
      onFormSubmit?.({ need: formNeed, details: formDetails });
      setFormNeed('');
      setFormDetails('');
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#313338] relative min-w-0 h-full overflow-hidden">
      <div className="h-12 px-4 shadow-sm flex items-center justify-between border-b border-[#2b2d31] flex-shrink-0 z-10 bg-[#313338]">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="text-xl text-[#80848e] font-bold">
            {activeChannel.type === ChannelType.TICKET ? '🔒' : activeChannel.type === ChannelType.FORM ? (activeChannel.id === 'suggestions' ? '💡' : '📝') : '#'}
          </span>
          <h2 className="font-bold text-white text-base truncate capitalize tracking-tight">{activeChannel.name}</h2>
          <div className="w-[1px] h-6 bg-[#3f4147] mx-2 hidden sm:block"></div>
          <p className="text-[11px] font-medium text-[#949ba4] truncate hidden sm:block">{activeChannel.description}</p>
        </div>
        {activeChannel.type === ChannelType.TICKET && isAdmin && (
          <button 
            onClick={() => onCloseTicket?.(activeChannel.id)}
            className="bg-[#f23f42] hover:bg-[#d83c3e] text-white text-[10px] px-3 py-1 rounded font-black uppercase tracking-widest transition-all"
          >
            Close Ticket
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto pt-4 space-y-4 custom-scrollbar">
        {activeChannel.type === ChannelType.FORM ? (
          <div className="max-w-xl mx-auto p-8 bg-[#2b2d31] rounded-2xl border border-white/5 my-10 shadow-2xl">
            {activeChannel.id === 'suggestions' ? (
              isAdmin ? (
                <div className="space-y-6">
                  <div className="flex flex-col items-center text-center">
                     <h1 className="text-2xl font-black text-white uppercase tracking-tighter mb-1">Nexus Suggestions</h1>
                     <p className="text-[#949ba4] text-xs font-medium">Review community requested features.</p>
                  </div>
                  <div className="space-y-4">
                    {suggestions.length === 0 ? (
                      <div className="text-center py-10 text-[#949ba4] italic text-sm">No suggestions yet.</div>
                    ) : (
                      suggestions.map(s => (
                        <div key={s.id} className="bg-[#1e1f22] p-4 rounded-xl border border-white/5 flex flex-col gap-3">
                           <div className="flex justify-between items-start">
                              <div className="flex items-center gap-2">
                                 <div className="w-8 h-8 rounded-full bg-[#f1c40f] flex items-center justify-center text-black font-black text-xs">{s.username[0].toUpperCase()}</div>
                                 <div>
                                    <p className="text-sm font-bold text-white">{s.username}</p>
                                    <p className="text-[10px] text-[#949ba4]">{new Date(s.timestamp).toLocaleString()}</p>
                                 </div>
                              </div>
                           </div>
                           <div className="space-y-1">
                              <p className="text-xs font-black text-[#f1c40f] uppercase tracking-widest">Want:</p>
                              <p className="text-sm text-white bg-[#2b2d31] p-2 rounded">{s.want}</p>
                           </div>
                           <div className="space-y-1">
                              <p className="text-xs font-black text-[#f1c40f] uppercase tracking-widest">Why:</p>
                              <p className="text-sm text-[#dbdee1] bg-[#2b2d31] p-2 rounded whitespace-pre-wrap">{s.why}</p>
                           </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ) : (
                <form onSubmit={handleGeneralFormSubmit} className="space-y-6">
                   <div className="flex flex-col items-center text-center">
                      <div className="w-12 h-12 mb-4 bg-[#f1c40f]/20 rounded-full flex items-center justify-center text-[#f1c40f] text-2xl">💡</div>
                      <h1 className="text-2xl font-black text-white uppercase tracking-tighter mb-1">Add to Nexus</h1>
                      <p className="text-[#949ba4] text-xs font-medium">Have an idea for a role, color, or feature?</p>
                   </div>
                   <div className="space-y-4">
                      <div className="space-y-1">
                         <label className="text-[10px] font-bold text-[#b5bac1] uppercase tracking-widest">Your Name</label>
                         <input disabled value={currentUser?.username} className="w-full bg-[#1e1f22] text-[#949ba4] px-4 py-3 rounded-lg border border-white/5" />
                      </div>
                      <div className="space-y-1">
                         <label className="text-[10px] font-bold text-[#b5bac1] uppercase tracking-widest">What do you want to see added?</label>
                         <input 
                           required
                           value={suggestionWant} 
                           onChange={(e) => setSuggestionWant(e.target.value)} 
                           placeholder="Feature name or description..." 
                           className="w-full bg-[#1e1f22] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#f1c40f] outline-none transition-all" 
                         />
                      </div>
                      <div className="space-y-1">
                         <label className="text-[10px] font-bold text-[#b5bac1] uppercase tracking-widest">Why should we add it?</label>
                         <textarea 
                           required
                           rows={4}
                           value={suggestionWhy} 
                           onChange={(e) => setSuggestionWhy(e.target.value)} 
                           placeholder="Explain the benefit to the community..." 
                           className="w-full bg-[#1e1f22] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#f1c40f] outline-none transition-all resize-none" 
                         />
                      </div>
                   </div>
                   <button className="w-full bg-[#f1c40f] hover:bg-[#d4ac0d] text-black font-black py-4 rounded-xl transition-all uppercase tracking-widest shadow-lg shadow-[#f1c40f]/20 active:scale-[0.98]">
                      Submit Suggestion
                   </button>
                </form>
              )
            ) : (
              isAdmin ? (
                <div className="space-y-6">
                  <div className="flex flex-col items-center text-center">
                     <h1 className="text-2xl font-black text-white uppercase tracking-tighter mb-1">Support Dashboard</h1>
                     <p className="text-[#949ba4] text-xs font-medium">Review pending support requests from users.</p>
                  </div>
                  <div className="space-y-4">
                    {submissions.length === 0 ? (
                      <div className="text-center py-10 text-[#949ba4] italic text-sm">No submissions yet.</div>
                    ) : (
                      submissions.map(sub => (
                        <div key={sub.id} className="bg-[#1e1f22] p-4 rounded-xl border border-white/5 flex flex-col gap-3">
                           <div className="flex justify-between items-start">
                              <div className="flex items-center gap-2">
                                 <div className="w-8 h-8 rounded-full bg-[#5865f2] flex items-center justify-center text-white font-black text-xs">{sub.username[0].toUpperCase()}</div>
                                 <div>
                                    <p className="text-sm font-bold text-white">{sub.username}</p>
                                    <p className="text-[10px] text-[#949ba4]">{new Date(sub.timestamp).toLocaleString()}</p>
                                 </div>
                              </div>
                              <span className={`text-[9px] px-2 py-0.5 rounded-full font-black uppercase ${sub.status === 'opened' ? 'bg-[#23a559]/20 text-[#23a559]' : 'bg-yellow-500/20 text-yellow-500'}`}>
                                 {sub.status}
                              </span>
                           </div>
                           <div className="space-y-1">
                              <p className="text-xs font-black text-[#5865f2] uppercase tracking-widest">Need:</p>
                              <p className="text-sm text-white bg-[#2b2d31] p-2 rounded">{sub.need}</p>
                           </div>
                           <div className="space-y-1">
                              <p className="text-xs font-black text-[#5865f2] uppercase tracking-widest">Details:</p>
                              <p className="text-sm text-[#dbdee1] bg-[#2b2d31] p-2 rounded whitespace-pre-wrap">{sub.details}</p>
                           </div>
                           {sub.status === 'pending' && (
                             <button 
                               onClick={() => onOpenTicket?.(sub.id)}
                               className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white text-xs font-black py-2 rounded-lg transition-all"
                             >
                               OPEN 1-1 CHAT
                             </button>
                           )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              ) : (
                <form onSubmit={handleGeneralFormSubmit} className="space-y-6">
                   <div className="flex flex-col items-center text-center">
                      <img src={NEXUS_LOGO_SVG} className="w-12 h-12 mb-4 object-contain" alt="N" />
                      <h1 className="text-2xl font-black text-white uppercase tracking-tighter mb-1">Talk to Brick</h1>
                      <p className="text-[#949ba4] text-xs font-medium">Need help with something? Let us know!</p>
                   </div>
                   <div className="space-y-4">
                      <div className="space-y-1">
                         <label className="text-[10px] font-bold text-[#b5bac1] uppercase tracking-widest">Your Name</label>
                         <input disabled value={currentUser?.username} className="w-full bg-[#1e1f22] text-[#949ba4] px-4 py-3 rounded-lg border border-white/5" />
                      </div>
                      <div className="space-y-1">
                         <label className="text-[10px] font-bold text-[#b5bac1] uppercase tracking-widest">What do you need?</label>
                         <input 
                           required
                           value={formNeed} 
                           onChange={(e) => setFormNeed(e.target.value)} 
                           placeholder="Short title of your request" 
                           className="w-full bg-[#1e1f22] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#5865f2] outline-none transition-all" 
                         />
                      </div>
                      <div className="space-y-1">
                         <label className="text-[10px] font-bold text-[#b5bac1] uppercase tracking-widest">Anything else?</label>
                         <textarea 
                           required
                           rows={4}
                           value={formDetails} 
                           onChange={(e) => setFormDetails(e.target.value)} 
                           placeholder="Explain your situation in detail..." 
                           className="w-full bg-[#1e1f22] text-white px-4 py-3 rounded-lg border border-transparent focus:border-[#5865f2] outline-none transition-all resize-none" 
                         />
                      </div>
                   </div>
                   <button className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white font-black py-4 rounded-xl transition-all uppercase tracking-widest shadow-lg shadow-[#5865f2]/20 active:scale-[0.98]">
                      Submit to Administration
                   </button>
                </form>
              )
            )}
            
            {/* Display private feedback for user in talk-to-brick/suggestions if they have any notifications */}
            <div className="mt-8 space-y-2">
              {visibleMessages.map(m => (
                <div key={m.id} className="bg-[#5865f2]/10 p-3 rounded-lg border border-[#5865f2]/30 text-xs text-[#dbdee1] text-center italic">
                   {m.text}
                </div>
              ))}
            </div>
          </div>
        ) : (
          visibleMessages.map((msg) => (
            <div key={msg.id} className={`px-4 py-1 flex gap-4 group hover:bg-[#2e3035] transition-colors ${msg.sender === 'SYSTEM' || msg.sender === 'NEXUS-AUDIT' ? 'bg-[#5865f2]/5 border-l-2 border-[#5865f2]' : ''}`}>
              <div className="flex-shrink-0 mt-0.5">
                <img src={msg.senderAvatar || (msg.sender === 'NEXUS-AUDIT' ? NEXUS_LOGO_SVG : `https://api.dicebear.com/7.x/initials/svg?seed=${msg.sender}&backgroundColor=5865f2`)} alt={msg.sender} className="w-10 h-10 rounded-xl object-cover bg-[#41434a] border border-white/5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span style={{ color: msg.tagColor || (msg.sender === 'Brick' ? '#ed4245' : msg.sender === 'NEXUS-AUDIT' ? '#5865f2' : 'white') }} className="text-[15px] font-bold tracking-tight hover:underline cursor-pointer">
                    {msg.equippedRole ? `(${msg.equippedRole}) ` : ''}{msg.sender}
                  </span>
                  <span className="text-[10px] text-[#949ba4] font-medium">{new Date(msg.timestamp).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>
                </div>
                {msg.text && (
                  <div className={`text-[15px] leading-relaxed break-words ${msg.sender === 'NEXUS-AUDIT' ? 'text-[#5865f2] font-mono font-bold italic text-xs' : 'text-[#dbdee1]'}`}>
                    {msg.text}
                  </div>
                )}
                {msg.imageUrl && (
                  <div className="mt-2 rounded-xl overflow-hidden border border-white/10 max-w-sm shadow-xl">
                    <img src={msg.imageUrl} alt="Nexus Broadcast" className="max-w-full h-auto object-contain bg-[#1e1f22]" />
                  </div>
                )}
              </div>
            </div>
          ))
        )}
        {(isTyping || isScanning) && (
          <div className="px-4 py-1 flex gap-4 items-center opacity-70">
            <div className="w-10 h-10 bg-[#1e1f22] border border-white/10 rounded-xl flex items-center justify-center overflow-hidden">
               <img src={NEXUS_LOGO_SVG} className="w-6 h-6 object-contain" alt="AI" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-[#949ba4] font-medium italic">{isScanning ? 'Deep-scanning image...' : 'AI thinking...'}</span>
              <div className="flex gap-1 mt-1"><div className="w-1 h-1 bg-[#5865f2] rounded-full animate-bounce"></div><div className="w-1 h-1 bg-[#5865f2] rounded-full animate-bounce [animation-delay:-0.15s]"></div><div className="w-1 h-1 bg-[#5865f2] rounded-full animate-bounce [animation-delay:-0.3s]"></div></div>
            </div>
          </div>
        )}
      </div>

      <div className="px-4 pb-6 flex-shrink-0 z-10 bg-[#313338] pt-2">
        {activeChannel.type === ChannelType.FORM ? (
          <div className="h-2"></div>
        ) : isTimedOut ? (
          <div className="bg-[#f23f42]/10 border border-[#f23f42]/30 rounded-lg flex flex-col items-center justify-center py-4 px-4 text-center animate-pulse">
            <p className="text-[#f23f42] font-bold text-sm uppercase tracking-wide mb-1">
              Account Suspended: {timeoutReason || 'Policy Violation'}
            </p>
            <p className="text-[#dbdee1] text-xs font-medium">Please wait {timeLeft} more seconds.</p>
          </div>
        ) : canChat ? (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => imageInputRef.current?.click()}
              disabled={isScanning}
              className="w-10 h-10 bg-[#383a40] hover:bg-[#404249] rounded-xl flex items-center justify-center transition-all border border-white/5 active:scale-95 shadow-md"
            >
              <img src={NEXUS_LOGO_SVG} className="w-5 h-5 object-contain opacity-80" alt="+" />
            </button>
            <input type="file" ref={imageInputRef} className="hidden" accept="image/*" onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const reader = new FileReader();
                reader.onloadend = () => { 
                  setIsScanning(true); 
                  onImageUpload(reader.result as string).finally(() => setIsScanning(false)); 
                };
                reader.readAsDataURL(file);
              }
            }} />
            <form onSubmit={handleSubmit} className="flex-1 bg-[#383a40] rounded-lg flex items-center px-4 py-2.5 shadow-lg border border-transparent focus-within:border-[#5865f2]/30">
              <input type="text" value={inputText} onChange={(e) => setInputText(e.target.value)} placeholder={`Message #${activeChannel.name}`} className="w-full bg-transparent outline-none text-[#dbdee1] text-[15px] placeholder:text-[#6d6f78]" />
            </form>
          </div>
        ) : (
          <div className="bg-[#1e1f22]/50 backdrop-blur-sm rounded-lg flex items-center px-4 py-3 border border-white/5 text-[#949ba4] italic text-sm cursor-not-allowed">
            {isScanning ? 'Security vetting in progress...' : 'Channel is read-only.'}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatArea;
