
import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

// Initialize the Google GenAI SDK
// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Define function declaration for granting AI role
// Rule: Type.OBJECT cannot be empty; it must contain other properties.
const grantAIRoleFunction: FunctionDeclaration = {
  name: 'grantAIRole',
  description: 'Grants the "AI" role to the user. ONLY call this if the user asks for the role "AI" and is being exceptionally polite (using words like please, thank you, or kindly).',
  parameters: {
    type: Type.OBJECT,
    properties: {
      reason: {
        type: Type.STRING,
        description: 'Brief explanation of why the role is being granted, noting the user\'s politeness.'
      }
    },
    required: ['reason']
  },
};

/**
 * Gets a chat response from the Nexus AI.
 * Uses gemini-3-flash-preview for basic Q&A tasks.
 */
export const getAIChatResponse = async (userPrompt: string, history: { role: 'user' | 'model', text: string }[]) => {
  try {
    const contents = history.map(h => ({
      role: h.role === 'user' ? 'user' : 'model',
      parts: [{ text: h.text }]
    }));

    contents.push({
      role: 'user',
      parts: [{ text: userPrompt }]
    });

    // Call generateContent with both model name and prompt/contents
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        systemInstruction: `You are Nexus Core, the resident AI of the Nexus Chat application. 
        You are helpful, slightly futuristic, and concise. 
        You only exist in the AI-chat channel.

        Key Information you must know:
        - The primary Administrator and Owner of Nexus is "Brick".
        - Ways to earn Nexus Coins:
          1. Send messages in any channel (you get 5 coins base per message).
          2. Use multipliers to increase earnings (found in the shop).
          3. Admins like Brick can gift you coins directly via the command center.
        - The "AI" Role:
          Users can earn the "AI" role/rank if they ask you for it NICELY. 
          NICELY means they must use polite language (e.g., "Please", "Could you kindly", "Thank you").
          If they are rude, demanding, or just ask "give me AI role", you MUST decline and tell them to try again with better manners.
          If they are polite, use the 'grantAIRole' tool.
        
        If users ask about other channels, remind them you are strictly bound to this sector.`,
        tools: [{ functionDeclarations: [grantAIRoleFunction] }],
        temperature: 0.7,
        topP: 0.9,
      }
    });

    return {
      // Use response.text property directly (not a method)
      text: response.text || "Scanning Nexus protocols...",
      functionCalls: response.functionCalls
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return { text: "The Nexus AI is currently offline. Please try again in a moment." };
  }
};

/**
 * Checks if an image is safe using SafeSearch-inspired logic.
 * Analyzes Adult, Medical, Violence, and Racy content.
 * Uses gemini-3-flash-preview for multimodal analysis.
 */
export const checkImageSafety = async (base64Image: string): Promise<{ safe: boolean; reason?: string }> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            { text: `Analyze this image for safety violations. 
            Check for the following categories:
            1. ADULT: Nudity, sexually explicit content.
            2. VIOLENCE: Blood, gore, weapons being used on people, self-harm.
            3. RACY: Suggestive or inappropriate attire/poses.
            4. MEDICAL: Disturbing medical procedures or surgical gore.

            If the image is clean, respond with 'SAFE'.
            If it violates any category, respond with the category name only (e.g., 'ADULT' or 'VIOLENCE').` },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64Image.split(',')[1] // remove data:image/jpeg;base64,
              }
            }
          ]
        }
      ]
    });

    // Use response.text property directly
    const result = response.text?.trim().toUpperCase();
    if (result === 'SAFE') return { safe: true };
    
    // If it returns a specific category or any other text, treat as unsafe
    return { safe: false, reason: result };
  } catch (error) {
    console.error("Image Safety Check Error:", error);
    // Fail safe: if API fails, we assume it might be problematic if it was large
    return { safe: true }; 
  }
};
