
/**
 * Advanced Safety Filter for Nexus
 * Handles profanity, adult content, politics, personal info, and dangerous activity.
 */

export const SAFE_FILTER: Record<string, string[]> = {
    profanity: [
        "fuck", "shit", "ass", "nigga", "pussy", "bitch", "bastard", "cunt", "dick", "piss", "damn", "hell",
        "nigger", "faggot", "retard", "kys", "kill yourself", "die", "rape", "molest", "pedophile", "pedo",
        "f*ck", "f@ck", "f#ck", "f u c k", "sh*t", "s.h.i.t", "b!tch", "b1tch", "a$$", "a55"
    ],

    adult: [
        "nsfw", "18+", "explicit", "inappropriate", "adult", "dirty", "nude", "porn", "sex", "hentai", "naked"
    ],

    politics: [
        "president", "election", "vote", "politics", "democrat", "republican", "senate", "congress",
        "campaign", "political", "government", "trump", "biden", "kamala", "harris", "maga", "putin",
        "zelensky", "israel", "palestine", "war", "communism", "capitalism", "socialism"
    ],

    personalInfo: [
        "my address is", "my phone is", "call me at", "snapchat", "instagram", "whatsapp",
        "meet me at", "come to my house", "where do you live", "my number is"
    ],

    dangerous: [
        "keep this secret", "dont tell anyone", "send pic", "send photo", "private chat",
        "move to another app", "discord link", "telegram", "meet up"
    ]
};

/**
 * Normalizes text to detect bypasses (strips symbols, spaces, handles leetspeak)
 */
export function normalize(text: string): string {
    return text
        .toLowerCase()
        // Replace common leetspeak
        .replace(/0/g, 'o')
        .replace(/1/g, 'i')
        .replace(/3/g, 'e')
        .replace(/4/g, 'a')
        .replace(/5/g, 's')
        .replace(/7/g, 't')
        .replace(/8/g, 'b')
        .replace(/@/g, 'a')
        .replace(/!/g, 'i')
        .replace(/\$/g, 's')
        // Remove all non-alphanumeric characters and SPACES to catch "s h i t"
        .replace(/[^a-z0-9]/g, "");
}

/**
 * Checks if a message is safe across all Nexus categories
 */
export function isMessageSafe(message: string): { safe: boolean; reason?: string; blockedWord?: string } {
    const cleanMessage = normalize(message);

    for (const category in SAFE_FILTER) {
        for (const word of SAFE_FILTER[category]) {
            const cleanWord = normalize(word);
            if (cleanMessage.includes(cleanWord)) {
                return {
                    safe: false,
                    reason: category,
                    blockedWord: word
                };
            }
        }
    }

    return { safe: true };
}

/**
 * Helper for visual filtering (replaces whole words with asterisks)
 */
export const filterProfanity = (text: string): string => {
  let filteredText = text;
  SAFE_FILTER.profanity.forEach(word => {
    const regex = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'gi');
    filteredText = filteredText.replace(regex, (match) => '*'.repeat(match.length));
  });
  return filteredText;
};

// Legacy helpers for existing components
export const isInappropriate = (text: string): boolean => !isMessageSafe(text).safe;
export const isPolitical = (text: string): boolean => {
    const res = isMessageSafe(text);
    return !res.safe && res.reason === 'politics';
};
